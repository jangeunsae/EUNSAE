//
//  main.swift
//  baseballGamelv6
//
//  Created by 장은새 on 6/5/25.
//

import Foundation

let game = BaseballGame()
game.start()
