
//  Created by 장은새 on 6/5/25.
import Foundation

// BaseballGame.swift 파일 생성
class RecordManager {
    //유저들의 게임 기록 배열
    private var recordArray: [Int] = []

    //유저의 게임 정보 입력
    func setRecordArray(_ count: Int) {
        recordArray.append(count)
    }
    
    //유저의 게임 정보 출력
    func getRecordArray() {
            if recordArray.isEmpty {
                print("기록이 존재하지 않습니다.")
            } else {
                print("\n< 게임 기록 보기 >")
                for (index, count) in recordArray.enumerated() {
                    print("\(index + 1)번째 게임 : 시도 횟수 - \(count)번")
                }
        }
    }
}
class BaseballGame {
    let recordManager = RecordManager()
    
    func start() {
        print("환영합니다. 원하시는 번호를 입력해주세요!")
        // 유저에게 입력값을 받음
        while true {
            //사용자가 "1"이라고 입력시 -> 1번 게임 시작하기 입력
            print("1. 게임 시작하기  2. 게임 기록 보기  3. 종료하기")
            let input = readLine()
            
            switch input {
            case "1":
                playGame()
                
            case "2":
                print("기록을 불러옵니다.")
                recordManager.getRecordArray()
                
            case "3":
                print("< 숫자 야구 게임을 종료합니다 >")
                exit(0)
            default:
                print("올바른 숫자를 입력해주세요!")
                
            }
        }
        
    func playGame() {
                let answer = makeAnswer() // 정답을 만드는 함수
                print(answer) // 실제 게임 시 삭제
                
                print("게임을 시작합니다! 0~9 사이의 중복되지 않은 숫자 3개를 입력하세요. 0은 맨 앞자리에 올 수 없습니다.")
                var tryCount = 0
                while true {
                    // 1. 유저에게 입력값을 받음
                    print("세 자리 숫자를 입력하세요 : ", terminator: "")
                    guard let input = readLine(), input.count == 3 else {
                        print("입력은 정확히 3자리 숫자여야 합니다.")
                        continue
                    }
                    
                    // 2. 정수가 아니면 처음으로 돌아가기
                    let userNumbers = input.compactMap { Int(String($0)) }
                    if userNumbers.count != 3 {
                        print("숫자만 입력해야 합니다.")
                        continue
                    }
                    
                    // 3. 0 포함 여부 & 중복 숫자 검사
                    if userNumbers[0] == 0 {
                        print("맨 앞자리에 0이 오는 것은 불가능합니다.")
                        continue
                    }
                    
                    if Set(userNumbers).count != 3 {
                        print("중복되지 않은 숫자 3개를 입력해야 합니다.")
                        continue
                    }
                    //게임 시도시 마다 +1
                    tryCount += 1
                    
                    // 4. 정답과 유저의 입력값을 비교하여 스트라이크/볼을 출력하기
                    var strike = 0
                    var ball = 0
                    
                    for (index, number) in userNumbers.enumerated() {
                        if number == answer[index] {
                            strike += 1
                        } else if answer.contains(number) {
                            ball += 1
                        }
                    }
                    
                    // 5. 정답이라면 break 호출하여 반복문 탈출
                    if strike == 0 && ball == 0 {
                        print("Nothing")
                    } else {
                        print("\(strike) 스트라이크, \(ball) 볼")
                        if strike == 3 {
                            print("정답입니다! 시도 횟수 \(tryCount)번, 게임을 종료합니다.")
                            recordManager.setRecordArray(tryCount)
                            break
                        }
                    }
                }
            }
    // 중복되지 않은 3자리 숫자를 생성하는 함수
    func makeAnswer() -> [Int] {
        let array = (0...9)
        var shuffledArray = array.shuffled()
                
        // 첫 숫자가 0이면 다시 섞음
        while shuffledArray[0] == 0 {
            shuffledArray = array.shuffled()
        }
                
        // 앞에서 3개 추출
        return Array(shuffledArray[0...2])
        }
            
    }
 }


